package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReactShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReactShopApplication.class, args);
	}

}
