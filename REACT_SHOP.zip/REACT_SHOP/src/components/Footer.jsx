import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 競好購. All rights reserved.</p>
    </footer>
  );
}
